<template>
    <div id="klineContainer">THIS IS KLINE</div>
</template>
<script>
export default {
  data: function() {
    return {};
  },
  created:function(){

  }
};
</script>